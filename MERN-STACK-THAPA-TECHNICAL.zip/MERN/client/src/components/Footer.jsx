import "./Footer.css";
function Footer() {
  return (
    <>
      <section className="footer">
        <p>@shahman 2024</p>
      </section>
    </>
  );
}

export default Footer;
